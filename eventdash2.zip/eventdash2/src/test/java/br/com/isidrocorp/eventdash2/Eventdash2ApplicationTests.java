package br.com.isidrocorp.eventdash2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Eventdash2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
