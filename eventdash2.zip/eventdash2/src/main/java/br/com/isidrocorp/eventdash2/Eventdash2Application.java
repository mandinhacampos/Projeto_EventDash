package br.com.isidrocorp.eventdash2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Eventdash2Application {

	public static void main(String[] args) {
		SpringApplication.run(Eventdash2Application.class, args);
	}

}
